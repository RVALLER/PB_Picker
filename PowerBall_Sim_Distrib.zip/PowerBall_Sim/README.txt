Read Me:

Run EXE by clicked the PowerBall_Sim executable

Instructions

i. Buttons:
	Generate Winning Numbers - Will Roll all 5 balls at once to give you numbers
				   for powerball drawings
	
	Populate Rules Display - Will make a popup explaining a very simplified
				 explanation of the rules of the game

	Populate Winners - Will make a popup window creating mock powerball winning
			   numbers to aid in the immersivness of simulation / picking

	Clear Canvas -     Will wipe the canvas of existing powerball tokens allowing 			   for more concise simulations

	Add Single Ball -  Will allow for user to generate one powerball number
			   either white or red, if only one number needed or
			   single generation at a time is desired

	Toggle Drawing Color - Functionality ties in with 'Add Single Ball'; this 
			       button toggles which color powerball is generated
                               from the 'Add single ball' button



Please use responsibly and enjoy :)



*** Gambling involves risk. Please only gamble with funds that you can comfortably afford to lose.***



NATIONAL PROBLEM GAMBLING HELPLINE
1-800-GAMBLER
The National Council on Problem Gambling operates the National Problem Gambling Helpline Network. The network is a single national access point to local resources for those seeking help for a gambling problem. The network consists of 28 contact centers that provide resources and referrals for all 50 states and US territories. Help is available 24/7 and is 100% confidential.

The National Problem Gambling Helpline Network also includes text and chat services. These features enable those who are gambling online or on their mobile phone to access help the same way they play. One call, text, or chat will get you to problem gambling help anywhere in the U.S. 24/7/365.